docker build -t odtp-travel-data-dashboard .


docker run -it --rm -v /Users/smaennel/odtp/components/odtp-travel-data-dashboard:/odtp/odtp-input -v /Users/smaennel/odtp/components/odtp-travel-data-dashboard:/odtp/odtp-output --env-file .env odtp-travel-data-dashboard